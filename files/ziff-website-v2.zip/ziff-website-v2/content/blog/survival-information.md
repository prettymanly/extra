---
title: "Survival information"
date: "2024-12-20"
excerpt: "The brain doesn't remember everything. It remembers what it needs to survive. What does that mean for your next presentation?"
---

# Survival information

The brain doesn't remember everything. It remembers what it needs to survive.

This is not a metaphor. It's neuroscience. Your brain is constantly filtering the flood of sensory input, deciding what matters and what doesn't. And the filter is brutal: if it doesn't seem relevant to survival—physical, social, emotional—it gets discarded.

This is why you remember where you were during a crisis but not what you had for lunch last Tuesday. This is why you remember the face of someone who wronged you but forget the names of people you've met at conferences. This is why certain moments in films stay with you forever while entire plotlines fade.

The brain asks: *Do I need this to survive?*

Now think about your last presentation. Your last workshop. Your last all-hands meeting.

Did anything you said register as survival information? Or did it all get filtered out as background noise?

Most corporate communication fails this test. It's information-dense but relevance-poor. It answers questions nobody was asking. It covers the material without ever making anyone feel like their survival depends on remembering it.

The best communicators understand this instinctively. They don't just share information—they make it feel urgent. They connect it to something the audience already cares about. They create stakes.

When I design sessions, I'm always asking: *What's the survival information here?* What's the one thing that, if they forget everything else, they absolutely need to remember? And then I design the whole experience around making that thing impossible to forget.

Everything else is decoration.
