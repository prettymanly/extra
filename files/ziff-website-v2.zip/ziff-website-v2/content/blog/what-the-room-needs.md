---
title: "What the room needs from you"
date: "2025-01-01"
excerpt: "Messenger isn't about charisma. It's about reading what the moment calls for."
---

# What the room needs from you

When I'm designing a session, one of the questions I keep coming back to is: *What does this moment need from me?*

Not: What do I want to say? Not: What would make me look good? Not: What's my usual style?

*What does this moment need from me?*

Sometimes the room needs energy. Someone to model enthusiasm, to give people permission to care. To be the first one to look silly so others can follow.

Sometimes the room needs calm. A steady presence. Someone who isn't rattled by the silence, who can hold space without filling it.

Sometimes the room needs challenge. The question no one wants to ask. The observation that might make people uncomfortable.

Sometimes the room needs warmth. Acknowledgment. The feeling that someone sees them.

The best facilitators I know aren't the most charismatic. They're the most adaptive. They read the room and adjust. They know how to dial up and dial down. They serve the moment, not their ego.

This is what I mean by Messenger. It's not about having a signature style. It's about range. It's about presence. It's about the discipline to ask: what does this moment need from me?

And then doing that thing—even if it's not your comfort zone.

The room is always telling you what it needs. Most people aren't listening.
