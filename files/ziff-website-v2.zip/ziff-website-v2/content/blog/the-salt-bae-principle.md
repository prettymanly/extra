---
title: "The Salt Bae principle"
date: "2025-01-08"
excerpt: "The salt-swan thing cost nothing. The steak cost a lot. So why do we walk into the office and accept forgettable?"
---

# The Salt Bae principle

You remember Salt Bae for the salt-swan thing, not the steak.

Think about that. The man runs high-end steakhouses. The product is a $500 piece of meat. Years of culinary training. Premium sourcing. Perfect cooking technique.

And yet—the thing that made him globally famous, the thing that launched a thousand memes, the thing you can picture right now if I mention his name—is the way he lets salt fall off his forearm.

The extra cost nothing. The steak cost a lot.

I've rewatched that Barry episode where a 12-year-old girl goes full feral mongoose, scales a tree, perches on a roof like a gargoyle, and bites a man's face. Season 2, Episode 5. Seven times. It had nothing to do with the plot.

You probably had a teacher growing up who went too far to make a point. You still remember what they taught you.

Meanwhile, we've all sat through dozens of workshops and probably struggle to name a single moment that stuck.

The workshop had a budget. The salt-swan didn't.

So why do we walk into the office and accept forgettable? Why do we design sessions that tick boxes instead of creating moments? Why do we cut the weird detail that might be the only thing anyone remembers?

I think it's fear. Fear of being too much. Fear of the thing that might not work. Fear of indulgence.

But the extra isn't indulgent. It's the point.

Be extra.
