---
title: "Kill your darlings (in facilitation)"
date: "2024-12-10"
excerpt: "That beautiful activity you spent 3 hours designing? It might be the thing that's killing the session."
---

# Kill your darlings (in facilitation)

Writers have this phrase: kill your darlings.

It means: the sentence you're most proud of, the turn of phrase you think is genius, the paragraph you keep reading back to yourself with satisfaction—that's probably the thing you need to cut. Because you're attached to it for the wrong reasons. You love it for what it says about you as a writer, not for what it does for the reader.

The same principle applies to facilitation.

That beautiful activity you spent 3 hours designing? The one with the clever metaphor and the perfectly crafted instructions? The one you can't wait to unveil?

It might be the thing that's killing the session.

I've done this more times than I'd like to admit. Fallen in love with an activity before I understood what the room actually needed. Forced a format because I wanted to use it, not because it was right. Kept something in the agenda because I'd already built the slides.

The room always knows. There's a subtle energy when something isn't landing—a restlessness, a politeness, a checking of phones. And in those moments, you have a choice: protect your darling, or serve the room.

The best facilitators I know are ruthless editors. They design more than they need, then cut in real-time based on what's working. They're not attached to their clever ideas. They're attached to the outcome.

Kill your darlings. The room will thank you.
