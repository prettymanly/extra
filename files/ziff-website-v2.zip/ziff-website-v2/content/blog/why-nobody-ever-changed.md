---
title: "Why nobody ever changed because of a slide"
date: "2025-01-15"
excerpt: "We've all sat through dozens of workshops and probably struggle to name a single moment that stuck. I think about that gap a lot."
---

# Why nobody ever changed because of a slide

We've all sat through dozens of workshops and probably struggle to name a single moment that stuck.

I think about that gap a lot.

The decks were fine. The facilitators were competent. The content was probably useful. And yet—nothing landed. No shift. No moment you'd mention to someone over dinner. No phrase that rewired how you thought about the problem.

Meanwhile, you can probably remember exactly where you were when a teacher said something that changed how you saw the world. Or the moment in a film that made you sit up. Or the detail in a presentation that made everyone in the room lean forward.

The difference isn't budget. It's not even skill. It's intention.

Most workshops are designed to transfer information. The best ones are designed to create moments. And those are very different design briefs.

Information transfer optimizes for coverage. Did we get through the content? Did we hit all the learning objectives? Can people pass the quiz?

Moment design optimizes for memory. What will they remember feeling? What will they tell someone else? What will change how they act, not just what they know?

The corporate world is drowning in information transfer. We need more moment design.

That's what I mean by extra. Not decorative. Not indulgent. The extra that makes the difference between forgettable and unforgettable.

Be extra.
